#! /usr/bin/env python
# coding: utf-8

from .model.core import BaseModel
from .handler.webHandler import BaseHandler


page_host='http://106.14.188.143/'